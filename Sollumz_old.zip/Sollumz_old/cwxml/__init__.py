"""Interface for managing CodeWalker XML files in an object oriented way."""
