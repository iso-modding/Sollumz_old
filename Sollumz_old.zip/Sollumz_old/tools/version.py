import bpy

USE_LEGACY = bpy.app.version[0] == 2
